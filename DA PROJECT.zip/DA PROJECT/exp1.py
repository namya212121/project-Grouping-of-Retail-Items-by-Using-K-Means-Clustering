import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler, LabelEncoder
import matplotlib.pyplot as plt

# Load your sales data into a Pandas DataFrame
# Replace 'your_data.csv' with the actual file path to your sales data
data = pd.read_csv('sales_data.csv')

# Clean column names if needed
data.columns = data.columns.str.strip()

# Encode 'month' column into numerical values
le = LabelEncoder()
data['month_encoded'] = le.fit_transform(data['month'])

# Extract relevant features for clustering
# Assuming 'year', 'month_encoded', 'item_count', 'transaction_value', and 'sales_count' are relevant features
features = data[['year', 'month_encoded', 'item_count', 'transaction_value', 'sales_count']]

# Perform k-means clustering with 3 clusters
kmeans = KMeans(n_clusters=3, random_state=42)
data['cluster'] = kmeans.fit_predict(StandardScaler().fit_transform(features[['item_count', 'transaction_value', 'sales_count']]))

# Calculate sales count for each product
product_sales_count = data.groupby(['product_id', 'year', 'month'])['sales_count'].sum().reset_index()
product_sales_count.columns = ['product_id', 'year', 'month', 'avg_sales_count']

# Set a threshold for 'sales_count' to classify as 'Fast Moving' or 'Slow Moving'
threshold = 0.60 * 200  # You can adjust this threshold as needed

data['movement_category'] = 'Slow Moving'
fast_moving_products = product_sales_count['product_id'][product_sales_count['avg_sales_count'] > threshold]
data.loc[data['product_id'].isin(fast_moving_products), 'movement_category'] = 'Fast Moving'

# Calculate minimum stock required based on movement category
data = data.merge(product_sales_count, on=['product_id', 'year', 'month'], how='left')
data['min_stock_required'] = 1.25 * data['avg_sales_count']
data.loc[data['movement_category'] == 'Slow Moving', 'min_stock_required'] *= 0.75

# Convert 'min_stock_required' to integer
data['min_stock_required'] = data['min_stock_required'].astype(int)

# Display the resulting data with movement categories and minimum stock required
result_data = data[['product_id', 'year', 'month', 'item_count', 'transaction_value', 'sales_count', 'movement_category', 'min_stock_required']]
result_data = result_data.drop_duplicates()  # Remove duplicate rows, if any

# Print the final resulting data
print(result_data)

# Visualize clusters with legend
scatter = plt.scatter(data['sales_count'], data['transaction_value'], c=data['cluster'], cmap='viridis')
plt.title('K-Means Clustering Results')
plt.xlabel('Sales Count')
plt.ylabel('Transaction Value')

# Create legend
legend_labels = ['Cluster 1', 'Cluster 2', 'Cluster 3']
plt.legend(handles=scatter.legend_elements()[0], labels=legend_labels, title='Clusters')

plt.show()
