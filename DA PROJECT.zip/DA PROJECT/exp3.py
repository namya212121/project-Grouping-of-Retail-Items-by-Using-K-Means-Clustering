import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler, LabelEncoder
import matplotlib.pyplot as plt

data = pd.read_csv('sales_data.csv')
data.columns = data.columns.str.strip()

le = LabelEncoder()
data['month_encoded'] = le.fit_transform(data['month'])
features = data[['year', 'month_encoded', 'item_count', 'transaction_value', 'sales_count']]
kmeans_all = KMeans(n_clusters=3, random_state=42)
data['cluster_all'] = kmeans_all.fit_predict(StandardScaler().fit_transform(features[['item_count', 'transaction_value', 'sales_count']]))

product_sales_count = data.groupby(['product_id', 'year', 'month'])['sales_count'].sum().reset_index()
product_sales_count.columns = ['product_id', 'year', 'month', 'avg_sales_count']
threshold = 0.60 * 200  
data['movement_category'] = 'Slow Moving'
fast_moving_products = product_sales_count['product_id'][product_sales_count['avg_sales_count'] > threshold]
data.loc[data['product_id'].isin(fast_moving_products), 'movement_category'] = 'Fast Moving'

fast_moving_data = data[data['movement_category'] == 'Fast Moving']
slow_moving_data = data[data['movement_category'] == 'Slow Moving']
kmeans_fast = KMeans(n_clusters=3, random_state=42)
fast_moving_data['cluster_fast'] = kmeans_fast.fit_predict(StandardScaler().fit_transform(fast_moving_data[['item_count', 'transaction_value', 'sales_count']]))
kmeans_slow = KMeans(n_clusters=3, random_state=42)
slow_moving_data['cluster_slow'] = kmeans_slow.fit_predict(StandardScaler().fit_transform(slow_moving_data[['item_count', 'transaction_value', 'sales_count']]))
result_data = data[['product_id', 'year', 'month', 'item_count', 'transaction_value', 'sales_count', 'movement_category', 'cluster_all']]
result_data = result_data.drop_duplicates() 
print(result_data)

scatter_all = plt.scatter(data['sales_count'], data['transaction_value'], c=data['cluster_all'], cmap='viridis', label='All Products')
plt.title('K-Means Clustering Results for All Products')
plt.xlabel('Sales Count')
plt.ylabel('Transaction Value')
legend_labels_all = ['Cluster 1', 'Cluster 2', 'Cluster 3']
plt.legend(handles=scatter_all.legend_elements()[0], labels=legend_labels_all, title='Clusters', loc='upper right')
plt.show()
result_data_fast = fast_moving_data[['product_id', 'year', 'month', 'item_count', 'transaction_value', 'sales_count', 'movement_category', 'cluster_fast']]
result_data_fast = result_data_fast.drop_duplicates() 
print(result_data_fast)
scatter_fast = plt.scatter(fast_moving_data['sales_count'], fast_moving_data['transaction_value'], c=fast_moving_data['cluster_fast'], cmap='viridis', marker='o', label='Fast Moving')
plt.title('K-Means Clustering Results for Fast Moving Products')
plt.xlabel('Sales Count')
plt.ylabel('Transaction Value')
legend_labels_fast = ['Cluster 1', 'Cluster 2', 'Cluster 3']
plt.legend(handles=scatter_fast.legend_elements()[0], labels=legend_labels_fast, title='Clusters', loc='upper right')
plt.show()

result_data_slow = slow_moving_data[['product_id', 'year', 'month', 'item_count', 'transaction_value', 'sales_count', 'movement_category', 'cluster_slow']]
result_data_slow = result_data_slow.drop_duplicates() 
print(result_data_slow)
scatter_slow = plt.scatter(slow_moving_data['sales_count'], slow_moving_data['transaction_value'], c=slow_moving_data['cluster_slow'], cmap='viridis', marker='o', label='Slow Moving')
plt.title('K-Means Clustering Results for Slow Moving Products')
plt.xlabel('Sales Count')
plt.ylabel('Transaction Value')
legend_labels_slow = ['Cluster 1', 'Cluster 2', 'Cluster 3']
plt.legend(handles=scatter_slow.legend_elements()[0], labels=legend_labels_slow, title='Clusters', loc='upper right')
plt.show()
